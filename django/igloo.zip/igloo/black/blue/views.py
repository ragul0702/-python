from django.shortcuts import render
from django.http import HttpResponse

def tamil(request):
    import datetime
    date = datetime.datetime.today()
    print (type(date))
    date1=date.strftime("%B %D %Y %H:%M")
    print (date1)
    return HttpResponse(date1)
def wel(request):
    f = [1,2,3,4]
    s=[]
    for i in f:
        s.append(i*2)
    if 6 in s:
        s[2]=60
    return HttpResponse(",<h1> program1: "+str(f[::-1])+"<h1> program2: "+str(s))
def wel1(request):
    a=10
    b=5
    c=a+b
    return HttpResponse(c)
def wel2(request):
    a=[]
    for i in range(50):
        print(i)
        a.append(i)
    return HttpResponse(a)
def wel3(request):
    msg ='hello world'
    'msg: {}'. format(msg)
    return HttpResponse(msg)   
   
def gud(requst):
    a=[]
    b=(input('enter the name'))
    h=(input('enter the name'))
    c=b+h
    print (c)
    for i in (c):
        a.append(i)
    print (a)
    a="".join(a)
    print (a)  
    return HttpResponse(a)
def ht(request):
    return render(request,'home.html')

def ht1(request):
    return render(request,'index.html')
def ht5(request):
    a=9
    return HttpResponse("a")
def ht6(request):
    return render(request,'table.html')
def ht7(request):
    return render(request,'house.html')

def ht8(request):
    return render(request,'username.html') 